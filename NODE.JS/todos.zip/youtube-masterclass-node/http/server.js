/**
 * Vai usar o http para criar um servidor
 * importou o módulo http
 * O server irá rodar na porta porta 5000
 * a variavel res é a resposta que o servidor vai dar
 */
const http = require('http')
const fs = require('fs')
const path = require('path')

http.createServer((req, res) => {
   /**
    * Criar um file padrão dependendo da URL
    * Verifica a resquisição se for / então coloca o arquivo indes.html no file
    * Se não for o / (que são os demais pedidos) coloca a url toda
    * Cria a variável que pega o path do arquivo
    */
   const file = req.url === '/' ? 'index.html' : req.url
   const filepath = path.join(__dirname, 'public', file)

   const allowedFyleTipes = ['.html', '.css', '.js']
   //grava a extensão do arquivo na variável
   const extname = path.extname(filepath)
   /**
    *faz uma função que retorna true se a extenção do arquivo for válida, 
    que existe na variável allowedFyleTipes
    */
   const allowed = allowedFyleTipes.find(item => item == extname)

    if(!allowed) return

   fs.readFile(
    filepath,
    (err, content) => {
        if (err) throw err

        res.end(content)
    }
   )
        
}).listen(5000, () => console.log('Server in running'))
