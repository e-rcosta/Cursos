/**
 * Vai usar o js para criar um servidor
 * importou o módulo http
 * O server irá rodar na porta porta 3000
 * a variavel res é a resposta que o servidor vai dar, nesse caso está 
 * recebendo o arquivo json
 */
const http = require('http')
const URL = require('url') 
const fs = require('fs')
const path = require('path')

const data = require('./urls.json')

//criou uma função apssando o callBack
function writeFile(cb){
     /**
     * writeFile possui as opções:
     * 1 - o caminho
     * 2 - os dados
     * 3 - callBack
     * stringfy possui 3 argumentos:
     * Primeiro os dados, o segundo ainda não iremos usar 
     * e o terceiro informa a quantidade de espaços do json para formatação
     */ 
    fs.writeFile(
        path.join(__dirname,"urls.json"),
        JSON.stringify(data, null, 2),
        err =>{
            if(err) throw err
            
            //mostra a mensagem ok, passa no formato json
            cb(JSON.stringify({message:"ok"}))
        }
    )
}

/**
 *utiliza o parse para capturar a query que está sendo passada
  na requisição da api com opção true que rtornará um objeto
 */
http.createServer((req, res) => {
   //criando as constantes name e url e extraindo seus valores da vonstante URL
   const {name, url, del} = URL.parse(req.url, true).query
   
   //permite acesso de qualquer lugar que quiser entrar na aplicação 
   res.writeHead(200,{
       'Access-Control-Allow-Origin': '*'
   })

   //all resources
   if (!name || !url)
        return res.end(JSON.stringify(data))
   /**
    O metódo filter deleta do arquivo data todas as url quando a fulsão 
    restornar false. Então para retornar false precisa verificar se a url
    do arquivo data é igual a url informada
    Ex: google.com.br é diferente de google.com.br? 
    Não, então a função retorna false.
    Então atualizado o data com as urls que serão mantidas e na sequencia
    atuaiza o arquivo com os dados de data
   */
   if (del){
        data.urls = data.urls.filter(item => String(item.url) !== String(url))
        return writeFile((message) => res.end(message))
    }    
   
   //data recebe os valores passados no path 
   data.urls.push({name, url}) 

   return writeFile((message) => res.end(message))  

}).listen(3000, () => console.log('Api in running'))
