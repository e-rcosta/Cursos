/**
 * Importou o módulo events de NODE
 */
const EventEmitter = require('events')

/**
 * Importa o módulo fs que vai trabalhar com os arquivos do sistema
 */
const fs = require('fs')

/**
 * Importa o módulo path do NODE
 */

const path = require ('path')

//Cria um objeto do tipo EventEmitter
const emitter = new EventEmitter()

/**
 * Fica ouvindo a palavra log
 */
emitter.on('log', (message) =>{
    /**
     * Passa como parêmatros: o arquivo que vai ser lido, a mesnagem e uma função callbak.
     * A função callback, que definimos como err, será executada se ouver erro.
     * Utilizamos o módulo path para passar o caminho do arquivo, usando o join, onde vai saber sozinho,
     * qual o nome da máquina, se é windows e vai sabe como criar o melhor caminho até o arquivo
     * onde tudo que precisa infromar é o dirname que diz o diretório atual e o arquivo (log.txt)
     */
    fs.appendFile(path.join(__dirname, 'log.txt'), (message), err => {
        if (err) throw err 
    } )
})

/**
 * Função que passa a mensagem apra ser emitida
 * @param {*} messag 
 */
function log (messag){
    emitter.emit('log', messag)
}

/**
 * Exporta a função log para que possa ser usada no sistema 
 */
module.exports = log



