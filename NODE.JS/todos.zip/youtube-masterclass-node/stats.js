//comando require importa módulos do NODE. Estamos importante o módulo os
const os = require('os')

/**
 * Criou a constante log importando do logger.js. Como o arquivo não é do NODE, que é o raiz
 * é necessário comocar o ponto + / ficando ./logger
 */
const log = require('./logger')

/**
   É uma função global
   Loop ficar sendo executado.
   Vai receber como argumento uma função anônima no formato Eral Function e o tempo em milesegundo
   que indica de quanto em quanto tempo a função será executada 
 */
setInterval (() => {

    //comando que extrai do módulo OS as funções da qtd de memória
    //essa estratégia faz a destruturação do objeto os
    const { freemem, totalmem} = os

    const total = parseInt(totalmem() / 1024 / 1024)
    const mem = parseInt(freemem() / 1024 / 1024)
    const percents = parseInt((mem / total) * 100) 

    //criou o objeto stats e formatou os valores
    const stats = {
        free: `${mem} MB`,
        total: `${total} MB`,
        usage: `${percents}%`
    }

    console.clear()
    console.table(stats)
    
    /**
     * Converteu um objeto javascript em um objeto Json de texto
     */
    log(`${JSON.stringify(stats)}\n`)

}, 1000)

