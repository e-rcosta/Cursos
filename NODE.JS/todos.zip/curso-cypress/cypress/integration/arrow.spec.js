it('nada agora', function() {})

const soma = (a, b) =>  a + b

//forma de escrever apenas quando usa um parâmetro
const soma1 = a =>  a + a


console.log(soma(1, 4))

console.log(soma1(1, 4))