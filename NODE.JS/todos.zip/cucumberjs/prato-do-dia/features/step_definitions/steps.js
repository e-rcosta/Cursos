const assert = require('assert');
const { Given, When, Then } = require('cucumber');

function pratoDoDia (dia){
    switch(dia){
        case 'segunda-feira' :
            return 'Carne de Sol e Arroz de Leite'
        
        case 'terça-feira' :   
            return 'Dobradinha'
    }
}

Given('que hoje é {string}', function (dia) {
    this.hoje = dia;
});

When('eu pergunto qual é o prato do dia', function () {
    this.valorObtido = pratoDoDia(this.hoje)
});

Then('a resposta deve ser {string}', function (valorEsperado) {
    assert.equal(this.valorObtido, valorEsperado)
});